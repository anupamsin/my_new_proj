package com.cybage.jpql_project.service;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

import com.cybage.jpql_project.model.Category;
import com.cybage.jpql_project.model.Product;

public interface ProductService {
    String createProd(Product product);

    Map<Integer, Product> getProductDet();

    Map<Integer, Product> getByCategory(Category category);

    Optional<Product> getById(Integer productId);

    String updateProd(Integer productId, Product product);

    Map<Integer, Product> getProdByPriceAndCat(String sortType, Category category);

    String productDelete(Integer productId);

    Map<Integer,Product> getByMultiCategory(String[] category);

	Map<Integer,Product> getDetailsByDateRange(LocalDate fromDate, LocalDate toDate);
}
