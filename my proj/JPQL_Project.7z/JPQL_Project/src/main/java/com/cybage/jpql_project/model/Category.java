package com.cybage.jpql_project.model;

public enum Category {
    GROCERY,
    ELECTRONICS,
    BOOKS,
    MEN_FASHION,
    WOMEN_FASHION
}
